def main():
    print("Hello from entrypoint-pkg!")
